import sqlite3

def create_and_populate_db():
    # Conectar ao banco de dados (ou criar um novo)
    conn = sqlite3.connect('kutiva_inhamissa.db')
    cursor = conn.cursor()
    
    # Ler o arquivo SQL
    with open('database.sql', 'r') as sql_file:
        sql_script = sql_file.read()
    
    # Executar o script SQL para criar e preencher as tabelas
    cursor.executescript(sql_script)
    
    # Fechar a conexão
    conn.commit()
    conn.close()

if __name__ == '__main__':
    create_and_populate_db()
    print("Banco de dados criado e populado com sucesso.")