-- Tabela de Usuários

CREATE TABLE IF NOT EXISTS users (

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    name TEXT NOT NULL,

    email TEXT UNIQUE NOT NULL,

    password TEXT NOT NULL,

    user_type TEXT CHECK( user_type IN ('student', 'teacher', 'explorer') ) NOT NULL,

    created_at DATETIME DEFAULT CURRENT_TIMESTAMP

);

-- Tabela de Livros

CREATE TABLE IF NOT EXISTS books (

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    title TEXT NOT NULL,

    author TEXT NOT NULL,

    description TEXT,

    file_url TEXT NOT NULL,

    uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP

);

-- Tabela de Logins

CREATE TABLE IF NOT EXISTS logins (

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    user_id INTEGER,

    login_time DATETIME DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (user_id) REFERENCES users(id)

);

-- Tabela de Mensagens (Comunicação entre Professor e Aluno)

CREATE TABLE IF NOT EXISTS messages (

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    sender_id INTEGER,

    receiver_id INTEGER,

    message TEXT NOT NULL,

    sent_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (sender_id) REFERENCES users(id),

    FOREIGN KEY (receiver_id) REFERENCES users(id)

);

-- Tabela para IA de Educação Visual

CREATE TABLE IF NOT EXISTS visual_ai (

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    user_id INTEGER,

    step_description TEXT NOT NULL,

    step_image TEXT,

    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (user_id) REFERENCES users(id)

);

-- Tabela para IA de Matemática, Física, História, Geografia, Filosofia e Gramática

CREATE TABLE IF NOT EXISTS subject_ai (

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    user_id INTEGER,

    subject TEXT CHECK( subject IN ('mathematics', 'physics', 'history', 'geography', 'philosophy', 'grammar') ) NOT NULL,

    content TEXT NOT NULL,

    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (user_id) REFERENCES users(id)

);